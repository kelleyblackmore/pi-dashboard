"""
Setup script for pi-dashboard.
Modern Python packages should use pyproject.toml, but this file
is kept for backwards compatibility and editable installs.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
