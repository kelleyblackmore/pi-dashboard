"""
Pi Dashboard - A comprehensive passenger dashboard system for Raspberry Pi 4.
"""

__version__ = "0.1.0"
__author__ = "Kelley Blackmore"
