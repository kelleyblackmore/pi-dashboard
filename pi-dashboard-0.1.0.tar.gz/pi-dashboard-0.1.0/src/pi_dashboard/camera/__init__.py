"""Camera module for displaying camera feeds."""

from .camera import CameraModule, CameraFeed

__all__ = ['CameraModule', 'CameraFeed']
